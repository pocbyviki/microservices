package com.cgi.banking.cgiconfigserverdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class CgiConfigServerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgiConfigServerDemoApplication.class, args);
	}

}
