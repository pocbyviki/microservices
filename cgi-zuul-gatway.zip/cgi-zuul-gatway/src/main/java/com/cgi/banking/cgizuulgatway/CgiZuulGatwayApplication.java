package com.cgi.banking.cgizuulgatway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

/**
 * once app is up and running then hit below url
 * http://localhost:8765/api/banking 
 * then it will be 
 * @author test
 *
 */
@SpringBootApplication
@EnableZuulProxy
@EnableDiscoveryClient
public class CgiZuulGatwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CgiZuulGatwayApplication.class, args);
	}

}
