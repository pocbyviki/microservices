package com.cgi.banking.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cgi.banking.models.CustomerNoSQL;

public interface CustomerRepository extends MongoRepository<CustomerNoSQL, Long>{

	@Query("{mobileNo : ?0}")
	public CustomerNoSQL findByMobileNo(@Param("no") long no);
	
	@Query(value="{mobileNo : ?0}", delete = true)
	public CustomerNoSQL deleteByMobileNo(@Param("no") long no);
	
}
