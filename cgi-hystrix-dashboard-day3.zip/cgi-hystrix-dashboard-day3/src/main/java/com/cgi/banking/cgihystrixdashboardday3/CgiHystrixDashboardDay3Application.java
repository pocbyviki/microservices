package com.cgi.banking.cgihystrixdashboardday3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;

@SpringBootApplication
@EnableHystrix
@EnableHystrixDashboard
@EnableCircuitBreaker
public class CgiHystrixDashboardDay3Application {

	public static void main(String[] args) {
		SpringApplication.run(CgiHystrixDashboardDay3Application.class, args);
	}

}
