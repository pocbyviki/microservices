package com.cgi.banking.cgihystrixdashboardday3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class RequestFallbackHandler {

	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="hystrixFallback")
	public String hystrixHanldeRequest() {
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:8084/getcustomers", HttpMethod.GET, null, String.class);
		return response.getBody();
	}
	
	public String hystrixFallback() {
		ResponseEntity<String> response = restTemplate.exchange("http://localhost:8085/getcustomers", HttpMethod.GET, null, String.class);
		return response.getBody();
	}
	
	
	@Bean
	public RestTemplate restTemplate() {
		
		return new RestTemplate();
	}
}
