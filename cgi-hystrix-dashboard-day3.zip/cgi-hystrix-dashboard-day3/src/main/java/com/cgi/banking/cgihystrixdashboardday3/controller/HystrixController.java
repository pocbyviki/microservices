package com.cgi.banking.cgihystrixdashboardday3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cgi.banking.cgihystrixdashboardday3.service.RequestFallbackHandler;

@RestController
public class HystrixController {

	@Autowired
	private RequestFallbackHandler requestFallbackHandler;
	@GetMapping("/getcustomers")
	public String handleRequest() {
		return requestFallbackHandler.hystrixHanldeRequest();
	}
}
