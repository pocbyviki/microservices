package com.cgi.banking.bankingapp;

import java.util.ArrayList;
import java.util.List;

public class Demo {

	public static void main(String[] args) {
		
		final List<String> list = new ArrayList();
		list.add("A");
		list.add("B");
		System.out.println(list);
		list.remove("B");
		
		System.out.println(list);
		
	}
}
